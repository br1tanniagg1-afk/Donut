package com.br1tannia.client.util;

/** Central colour palette for Br1tannia Client. */
public final class ColorUtil {

    private ColorUtil() {}

    // ── Brand colours (ARGB) ─────────────────────────────────────────────────
    public static final int BG_DARK        = 0xE0101318; // panel background
    public static final int BG_PANEL       = 0xE0151C26; // module list bg
    public static final int ACCENT_BLUE    = 0xFF1A6FD4; // primary accent
    public static final int ACCENT_BLUE_DIM= 0xFF1250A0; // hover / selected
    public static final int TEXT_PRIMARY   = 0xFFEEEEEE;
    public static final int TEXT_SECONDARY = 0xFF8899AA;
    public static final int ENABLED_GREEN  = 0xFF3ECF6E;
    public static final int DISABLED_GREY  = 0xFF556677;
    public static final int SEPARATOR      = 0xFF1E2D40;
    public static final int SLIDER_TRACK   = 0xFF1E2D40;
    public static final int SLIDER_FILL    = 0xFF1A6FD4;
    public static final int HUD_BG         = 0xCC0D1017;
    public static final int HUD_TEXT       = 0xFFCCDDEE;
    public static final int HUD_SOUND_TAG  = 0xFF1A6FD4;

    /** Returns an ARGB int with the given alpha applied. */
    public static int withAlpha(int argb, int alpha) {
        return (argb & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }
}
