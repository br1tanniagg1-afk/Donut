package com.br1tannia.client.module.modules.movement;

import com.br1tannia.client.module.Category;
import com.br1tannia.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * Freecam – detaches the camera from the player so you can fly it around freely.
 * The actual player entity stays put; camera offset is applied via the GameRendererMixin.
 */
public class Freecam extends Module {

    // Camera world position
    public double camX, camY, camZ;
    public float  camYaw, camPitch;

    // Player state saved when freecam activates
    private Vec3d savedPos;
    private float savedYaw, savedPitch;

    // ── Settings keys ────────────────────────────────────────────────────────
    public static final String SETTING_SPEED = "Speed";

    public Freecam() {
        super("Freecam", "Move your camera independently of your character.", Category.MOVEMENT);
        registerFloat(SETTING_SPEED, 0.5f);
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) { setEnabled(false); return; }

        savedPos   = mc.player.getPos();
        savedYaw   = mc.player.getYaw();
        savedPitch = mc.player.getPitch();

        camX   = savedPos.x;
        camY   = savedPos.y + mc.player.getStandingEyeHeight();
        camZ   = savedPos.z;
        camYaw   = savedYaw;
        camPitch = savedPitch;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || savedPos == null) return;

        // Snap player back to original position
        mc.player.setPos(savedPos.x, savedPos.y, savedPos.z);
        mc.player.setYaw(savedYaw);
        mc.player.setPitch(savedPitch);
    }

    /**
     * Called every client tick while enabled.
     * Translates held movement keys into camera position delta.
     */
    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float speed    = getFloat(SETTING_SPEED);
        double yawRad  = Math.toRadians(camYaw);
        camPitch       = mc.player.getPitch(); // keep pitch from mouse look
        camYaw         = mc.player.getYaw();

        double dx = 0, dy = 0, dz = 0;

        if (mc.options.forwardKey.isPressed()) {
            dx -= Math.sin(yawRad) * speed;
            dz += Math.cos(yawRad) * speed;
        }
        if (mc.options.backKey.isPressed()) {
            dx += Math.sin(yawRad) * speed;
            dz -= Math.cos(yawRad) * speed;
        }
        if (mc.options.leftKey.isPressed()) {
            dx -= Math.cos(yawRad) * speed;
            dz -= Math.sin(yawRad) * speed;
        }
        if (mc.options.rightKey.isPressed()) {
            dx += Math.cos(yawRad) * speed;
            dz += Math.sin(yawRad) * speed;
        }
        if (mc.options.jumpKey.isPressed())  dy += speed;
        if (mc.options.sneakKey.isPressed()) dy -= speed;

        camX += dx;
        camY += dy;
        camZ += dz;

        // Keep the player entity frozen in place
        mc.player.setPos(savedPos.x, savedPos.y, savedPos.z);
        mc.player.setVelocity(Vec3d.ZERO);
        mc.player.fallDistance = 0;
    }
}
