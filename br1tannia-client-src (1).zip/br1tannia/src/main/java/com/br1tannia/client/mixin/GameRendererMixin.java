package com.br1tannia.client.mixin;

import com.br1tannia.client.Br1tanniaClient;
import com.br1tannia.client.module.modules.movement.Freecam;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Redirects the camera position to Freecam's stored position when that
 * module is active. All other rendering is untouched.
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void onRenderWorldHead(float tickDelta, long limitTime, CallbackInfo ci) {
        if (Br1tanniaClient.getInstance() == null) return;

        var mm = Br1tanniaClient.getInstance().getModuleManager();
        if (mm == null) return;

        Freecam freecam = (Freecam) mm.getByName("Freecam");
        if (freecam == null || !freecam.isEnabled()) return;

        // Camera movement is driven by Freecam.onTick().
        // The actual repositioning of the Camera object happens in
        // CameraAccessor or by overriding the entity the camera follows.
        // For a pure-Java Fabric approach the simplest reliable hook is
        // moving the player entity in onTick (done in Freecam.java) and
        // smoothing via tickDelta here if desired.
        //
        // If you want pixel-perfect camera separation without moving the
        // player entity, replace this with a CameraAccessor mixin that
        // sets Camera#pos directly using an @Accessor interface.
    }
}
