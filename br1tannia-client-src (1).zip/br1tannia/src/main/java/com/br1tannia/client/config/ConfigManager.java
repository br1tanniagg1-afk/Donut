package com.br1tannia.client.config;

import com.br1tannia.client.Br1tanniaClient;
import com.br1tannia.client.module.Module;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;
import java.util.Map;

/**
 * Saves and loads module enabled state + settings to/from
 * .minecraft/config/br1tannia.json using Gson (bundled with Minecraft).
 */
public class ConfigManager {

    private final Path configFile;

    public ConfigManager() {
        configFile = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("br1tannia.json");
    }

    // ── Save ──────────────────────────────────────────────────────────────────

    public void save() {
        JsonObject root = new JsonObject();

        for (Module m : Br1tanniaClient.getInstance()
                .getModuleManager().getAll()) {
            JsonObject moduleObj = new JsonObject();
            moduleObj.addProperty("enabled", m.isEnabled());
            moduleObj.addProperty("keybind", m.getKeybind());

            JsonObject settingsObj = new JsonObject();
            for (Map.Entry<String, Object> entry : m.getSettings().entrySet()) {
                Object v = entry.getValue();
                if      (v instanceof Boolean b) settingsObj.addProperty(entry.getKey(), b);
                else if (v instanceof Float   f) settingsObj.addProperty(entry.getKey(), f);
                else if (v instanceof Integer i) settingsObj.addProperty(entry.getKey(), i);
                else if (v instanceof String  s) settingsObj.addProperty(entry.getKey(), s);
            }
            moduleObj.add("settings", settingsObj);
            root.add(m.getName(), moduleObj);
        }

        try (Writer w = new FileWriter(configFile.toFile())) {
            new GsonBuilder().setPrettyPrinting().create().toJson(root, w);
        } catch (IOException e) {
            Br1tanniaClient.LOGGER.error("[Br1tannia] Failed to save config", e);
        }
    }

    // ── Load ──────────────────────────────────────────────────────────────────

    public void load() {
        if (!configFile.toFile().exists()) return;

        try (Reader r = new FileReader(configFile.toFile())) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();

            for (Module m : Br1tanniaClient.getInstance()
                    .getModuleManager().getAll()) {
                if (!root.has(m.getName())) continue;
                JsonObject moduleObj = root.getAsJsonObject(m.getName());

                if (moduleObj.has("enabled"))
                    m.setEnabled(moduleObj.get("enabled").getAsBoolean());

                if (moduleObj.has("keybind"))
                    m.setKeybind(moduleObj.get("keybind").getAsInt());

                if (moduleObj.has("settings")) {
                    JsonObject settingsObj = moduleObj.getAsJsonObject("settings");
                    for (Map.Entry<String, Object> entry : m.getSettings().entrySet()) {
                        if (!settingsObj.has(entry.getKey())) continue;
                        JsonElement el = settingsObj.get(entry.getKey());
                        Object cur = entry.getValue();
                        if      (cur instanceof Boolean) m.setSetting(entry.getKey(), el.getAsBoolean());
                        else if (cur instanceof Float)   m.setSetting(entry.getKey(), el.getAsFloat());
                        else if (cur instanceof Integer) m.setSetting(entry.getKey(), el.getAsInt());
                        else if (cur instanceof String)  m.setSetting(entry.getKey(), el.getAsString());
                    }
                }
            }
        } catch (Exception e) {
            Br1tanniaClient.LOGGER.error("[Br1tannia] Failed to load config", e);
        }
    }
}
