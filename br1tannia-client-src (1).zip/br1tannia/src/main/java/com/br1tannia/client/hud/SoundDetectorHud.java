package com.br1tannia.client.hud;

import com.br1tannia.client.Br1tanniaClient;
import com.br1tannia.client.module.modules.world.BaseSoundDetector;
import com.br1tannia.client.module.modules.world.BaseSoundDetector.SoundEvent;
import com.br1tannia.client.util.ColorUtil;
import com.br1tannia.client.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD overlay for BaseSoundDetector.
 * Renders in the top-right corner by default; position is configurable.
 */
public class SoundDetectorHud extends HudElement {

    private static final int MAX_DISPLAY = 10;
    private static final int ROW_H       = 10;
    private static final int PANEL_W     = 240;
    private static final int HEADER_H    = 12;
    private static final int PADDING     = 4;

    public SoundDetectorHud() {
        // Positioned at top-right; recalculated on each render to handle resize
        x = 0;
        y = 20;
    }

    @Override
    public void render(DrawContext ctx, float delta) {
        if (!visible) return;

        var client = MinecraftClient.getInstance();
        if (client.currentScreen != null) return; // hide when GUI is open

        var mm = Br1tanniaClient.getInstance().getModuleManager();
        if (mm == null) return;

        BaseSoundDetector detector =
                (BaseSoundDetector) mm.getByName("BaseSoundDetector");
        if (detector == null || !detector.isEnabled()) return;
        if (!detector.getBool(BaseSoundDetector.SETTING_SHOW_HUD)) return;

        SoundEvent[] events = detector.getHistorySnapshot();
        int count = Math.min(events.length, MAX_DISPLAY);

        int panelH = HEADER_H + count * ROW_H + PADDING * 2;
        int px     = client.getWindow().getScaledWidth() - PANEL_W - 4;
        int py     = y;

        // Background
        RenderUtil.fillRect(ctx, px, py, PANEL_W, panelH, ColorUtil.HUD_BG);
        RenderUtil.drawOutline(ctx, px, py, PANEL_W, panelH, ColorUtil.ACCENT_BLUE_DIM);

        // Header
        RenderUtil.drawString(ctx, client.textRenderer,
                "§bBase Sound Detector", px + PADDING, py + 2, ColorUtil.ACCENT_BLUE);

        int ry = py + HEADER_H + PADDING;
        if (count == 0) {
            RenderUtil.drawString(ctx, client.textRenderer,
                    "No sounds detected.", px + PADDING, ry, ColorUtil.TEXT_SECONDARY);
        } else {
            for (int i = 0; i < count; i++) {
                SoundEvent e   = events[i];
                String dist    = e.distance >= 0
                        ? String.format("%.0fm", e.distance) : "?";
                String line    = e.name + "  " + e.direction + "  " + dist
                        + "  §8" + e.timestamp;
                RenderUtil.drawString(ctx, client.textRenderer,
                        line, px + PADDING, ry, ColorUtil.HUD_TEXT);
                ry += ROW_H;
            }
        }
    }
}
