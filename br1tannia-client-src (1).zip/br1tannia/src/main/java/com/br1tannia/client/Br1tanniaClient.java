package com.br1tannia.client;

import com.br1tannia.client.config.ConfigManager;
import com.br1tannia.client.gui.ClickGUI;
import com.br1tannia.client.hud.HudManager;
import com.br1tannia.client.keybind.KeybindManager;
import com.br1tannia.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Br1tanniaClient implements ClientModInitializer {

    public static final String MOD_NAME    = "Br1tannia Client";
    public static final String MOD_VERSION = "1.0.0";
    public static final Logger LOGGER      = LoggerFactory.getLogger("br1tannia");

    private static Br1tanniaClient instance;

    private ModuleManager  moduleManager;
    private ConfigManager  configManager;
    private KeybindManager keybindManager;
    private HudManager     hudManager;
    private ClickGUI       clickGUI;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[Br1tannia] Starting up...");

        moduleManager  = new ModuleManager();
        configManager  = new ConfigManager();
        keybindManager = new KeybindManager();
        hudManager     = new HudManager();
        clickGUI       = new ClickGUI();

        moduleManager.registerModules();
        moduleManager.init();
        keybindManager.register();
        configManager.load();

        // HUD renders every frame on the client
        HudRenderCallback.EVENT.register((drawContext, tickDelta) ->
            hudManager.render(drawContext, tickDelta)
        );

        LOGGER.info("[Br1tannia] Ready.");
    }

    public static Br1tanniaClient getInstance()  { return instance;       }
    public ModuleManager  getModuleManager()     { return moduleManager;  }
    public ConfigManager  getConfigManager()     { return configManager;  }
    public KeybindManager getKeybindManager()    { return keybindManager; }
    public HudManager     getHudManager()        { return hudManager;     }
    public ClickGUI       getClickGUI()          { return clickGUI;       }
}
