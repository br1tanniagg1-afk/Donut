package com.br1tannia.client.module.modules.world;

import com.br1tannia.client.module.Category;
import com.br1tannia.client.module.Module;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;

/**
 * BaseSoundDetector – listens for sounds the client actually receives and
 * filters for ones commonly associated with nearby player bases.
 *
 * The SoundSystemMixin calls onSoundPlayed() every time the Minecraft sound
 * engine plays a sound. We check the identifier against our watchlist and
 * record a SoundEvent if it matches.
 */
public class BaseSoundDetector extends Module {

    public static final int MAX_HISTORY = 50;

    private static final DateTimeFormatter TIME_FMT =
            DateTimeFormatter.ofPattern("HH:mm:ss");

    // ── Settings keys ────────────────────────────────────────────────────────
    public static final String SETTING_SHOW_HUD     = "ShowHUD";
    public static final String SETTING_MAX_RANGE    = "MaxRange";

    // Sounds that commonly indicate a base
    private static final Set<String> WATCHLIST = Set.of(
        "minecraft:block.chest.open",
        "minecraft:block.chest.close",
        "minecraft:block.enderchest.open",
        "minecraft:block.enderchest.close",
        "minecraft:block.barrel.open",
        "minecraft:block.barrel.close",
        "minecraft:block.shulker_box.open",
        "minecraft:block.shulker_box.close",
        "minecraft:block.piston.extend",
        "minecraft:block.piston.contract",
        "minecraft:block.wooden_door.open",
        "minecraft:block.wooden_door.close",
        "minecraft:block.iron_door.open",
        "minecraft:block.iron_door.close",
        "minecraft:block.wooden_trapdoor.open",
        "minecraft:block.wooden_trapdoor.close",
        "minecraft:block.iron_trapdoor.open",
        "minecraft:block.iron_trapdoor.close",
        "minecraft:block.dispenser.dispense",
        "minecraft:block.dispenser.fail",
        "minecraft:block.dropper.dispense",
        "minecraft:block.furnace.fire_crackle",
        "minecraft:block.note_block.harp",
        "minecraft:entity.villager.ambient",
        "minecraft:entity.villager.trade",
        "minecraft:block.anvil.use",
        "minecraft:block.grindstone.use",
        "minecraft:ui.cartography_table.take_result",
        "minecraft:block.generic.break",
        "minecraft:block.generic.place"
    );

    // Circular log of recent detections exposed to the HUD
    private final Deque<SoundEvent> history = new ArrayDeque<>();

    public BaseSoundDetector() {
        super("BaseSoundDetector",
              "Logs nearby sounds that may indicate a player base.",
              Category.WORLD);
        registerBool(SETTING_SHOW_HUD,  true);
        registerFloat(SETTING_MAX_RANGE, 64f);
    }

    /** Called by SoundSystemMixin whenever a sound plays. */
    public void onSoundPlayed(String soundId, double x, double y, double z) {
        if (!isEnabled()) return;

        String id = normalise(soundId);
        if (!WATCHLIST.contains(id)) return;

        String timestamp = LocalTime.now().format(TIME_FMT);
        String label     = friendlyName(id);
        String direction = computeDirection(x, y, z);
        double distance  = computeDistance(x, y, z);

        SoundEvent event = new SoundEvent(label, direction, distance, timestamp, id);

        synchronized (history) {
            history.addFirst(event);
            if (history.size() > MAX_HISTORY) history.removeLast();
        }
    }

    public void clearHistory() {
        synchronized (history) { history.clear(); }
    }

    /** Thread-safe snapshot for the HUD. */
    public SoundEvent[] getHistorySnapshot() {
        synchronized (history) {
            return history.toArray(new SoundEvent[0]);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String normalise(String id) {
        // Strip namespace if missing so comparisons always match "namespace:path"
        if (!id.contains(":")) return "minecraft:" + id;
        return id.toLowerCase();
    }

    private double computeDistance(double x, double y, double z) {
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null) return -1;
        double dx = mc.player.getX() - x;
        double dy = mc.player.getY() - y;
        double dz = mc.player.getZ() - z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private String computeDirection(double x, double y, double z) {
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null) return "?";
        double dx = x - mc.player.getX();
        double dz = z - mc.player.getZ();
        double angle = Math.toDegrees(Math.atan2(dz, dx));
        // Convert to compass
        String[] dirs = {"E","NE","N","NW","W","SW","S","SE"};
        int idx = (int) Math.round(angle / 45.0) & 7;
        return dirs[idx];
    }

    private String friendlyName(String id) {
        // e.g. "minecraft:block.chest.open" -> "Chest Open"
        String path = id.contains(":") ? id.split(":")[1] : id;
        String[] parts = path.split("\\.");
        if (parts.length >= 2) {
            String obj    = capitalise(parts[parts.length - 2]);
            String action = capitalise(parts[parts.length - 1]);
            return obj + " " + action;
        }
        return capitalise(path);
    }

    private String capitalise(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    // ── Inner record ──────────────────────────────────────────────────────────

    public static class SoundEvent {
        public final String name;
        public final String direction;
        public final double distance;
        public final String timestamp;
        public final String soundId;

        public SoundEvent(String name, String direction, double distance,
                          String timestamp, String soundId) {
            this.name      = name;
            this.direction = direction;
            this.distance  = distance;
            this.timestamp = timestamp;
            this.soundId   = soundId;
        }

        public String format() {
            String dist = distance >= 0
                ? String.format("%.1fm", distance)
                : "?m";
            return String.format("[%s] %s  %s  %s", timestamp, name, direction, dist);
        }
    }
}
