package com.br1tannia.client.module;

import com.br1tannia.client.module.modules.movement.Freecam;
import com.br1tannia.client.module.modules.world.BaseSoundDetector;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    /** Register every module here. */
    public void registerModules() {
        register(new Freecam());
        register(new BaseSoundDetector());
        // Add future modules below this line
    }

    private void register(Module module) {
        modules.add(module);
    }

    /** Hook module tick into the client tick event. Call once during init. */
    public void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            for (Module m : modules) {
                if (m.isEnabled()) m.onTick();
            }
        });
    }

    public List<Module> getAll() {
        return modules;
    }

    public List<Module> getByCategory(Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Module getByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }
}
