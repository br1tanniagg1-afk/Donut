package com.br1tannia.client.hud;

import com.br1tannia.client.Br1tanniaClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Owns all HUD elements and drives their render calls. */
public class HudManager {

    private final List<HudElement> elements = new ArrayList<>();
    private SoundDetectorHud soundHud;

    public HudManager() {
        soundHud = new SoundDetectorHud();
        elements.add(soundHud);
    }

    public void render(DrawContext ctx, float delta) {
        for (HudElement el : elements) {
            el.render(ctx, delta);
        }
    }

    public SoundDetectorHud getSoundHud() { return soundHud; }
}
