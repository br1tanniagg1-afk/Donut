package com.br1tannia.client.util;

import net.minecraft.client.gui.DrawContext;

/** Thin wrappers around DrawContext so individual classes stay clean. */
public final class RenderUtil {

    private RenderUtil() {}

    public static void fillRect(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + h, color);
    }

    public static void drawOutline(DrawContext ctx, int x, int y, int w, int h, int color) {
        // top
        ctx.fill(x,         y,         x + w,     y + 1,     color);
        // bottom
        ctx.fill(x,         y + h - 1, x + w,     y + h,     color);
        // left
        ctx.fill(x,         y,         x + 1,     y + h,     color);
        // right
        ctx.fill(x + w - 1, y,         x + w,     y + h,     color);
    }

    public static void drawString(DrawContext ctx,
                                   net.minecraft.client.font.TextRenderer font,
                                   String text, int x, int y, int color) {
        ctx.drawTextWithShadow(font, text, x, y, color);
    }
}
