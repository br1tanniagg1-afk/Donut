package com.br1tannia.client.module;

public enum Category {
    MOVEMENT     ("Movement"),
    WORLD        ("World"),
    VISUAL       ("Visual"),
    MISCELLANEOUS("Miscellaneous");

    public final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }
}
