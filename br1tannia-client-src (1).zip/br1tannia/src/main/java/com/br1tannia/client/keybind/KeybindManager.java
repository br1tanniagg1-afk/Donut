package com.br1tannia.client.keybind;

import com.br1tannia.client.Br1tanniaClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Registers and handles all client keybinds.
 * Right Shift toggles the ClickGUI.
 * Module keybinds are checked here too.
 */
public class KeybindManager {

    private KeyBinding guiKey;

    public void register() {
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.br1tannia.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.br1tannia"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // GUI toggle
            while (guiKey.wasPressed()) {
                var gui = Br1tanniaClient.getInstance().getClickGUI();
                if (client.currentScreen == gui) {
                    client.setScreen(null);
                } else {
                    client.setScreen(gui);
                }
            }

            // Module keybinds
            if (client.currentScreen == null) {
                for (var module : Br1tanniaClient.getInstance()
                        .getModuleManager().getAll()) {
                    int key = module.getKeybind();
                    if (key != -1 && InputUtil.isKeyPressed(
                            client.getWindow().getHandle(), key)) {
                        module.toggle();
                    }
                }
            }
        });
    }

    public KeyBinding getGuiKey() { return guiKey; }
}
