package com.br1tannia.client.gui;

import com.br1tannia.client.Br1tanniaClient;
import com.br1tannia.client.module.Category;
import com.br1tannia.client.module.Module;
import com.br1tannia.client.util.ColorUtil;
import com.br1tannia.client.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Main ClickGUI screen.
 * One panel per category, laid out horizontally.
 * Clicking a module toggles it; right-clicking opens its settings panel.
 */
public class ClickGUI extends Screen {

    private static final int PANEL_WIDTH    = 140;
    private static final int PANEL_HEADER   = 20;
    private static final int MODULE_HEIGHT  = 18;
    private static final int PANEL_PADDING  = 6;
    private static final int START_X        = 10;
    private static final int START_Y        = 10;
    private static final int PANEL_GAP      = 6;

    private final List<CategoryPanel> panels = new ArrayList<>();

    // Currently open settings panel (null = none)
    private Module settingsTarget = null;
    private int    settingsX, settingsY;

    public ClickGUI() {
        super(Text.literal("Br1tannia Client"));
    }

    /** Call this to open the GUI. */
    public void open() {
        MinecraftClient.getInstance().setScreen(this);
    }

    @Override
    protected void init() {
        panels.clear();
        int x = START_X;
        for (Category cat : Category.values()) {
            List<Module> mods = Br1tanniaClient.getInstance()
                    .getModuleManager().getByCategory(cat);
            if (!mods.isEmpty()) {
                int height = PANEL_HEADER + mods.size() * MODULE_HEIGHT + PANEL_PADDING;
                panels.add(new CategoryPanel(cat, mods, x, START_Y,
                        PANEL_WIDTH, height));
                x += PANEL_WIDTH + PANEL_GAP;
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dim background
        RenderUtil.fillRect(ctx, 0, 0, this.width, this.height,
                ColorUtil.withAlpha(0x000000, 120));

        // Title bar
        RenderUtil.fillRect(ctx, 0, 0, this.width, 14, ColorUtil.BG_DARK);
        RenderUtil.drawString(ctx, textRenderer,
                "Br1tannia Client  v" + Br1tanniaClient.MOD_VERSION,
                4, 3, ColorUtil.ACCENT_BLUE);

        for (CategoryPanel p : panels) p.render(ctx, textRenderer, mouseX, mouseY);

        // Settings panel overlay
        if (settingsTarget != null) {
            renderSettingsPanel(ctx, mouseX, mouseY);
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Close settings panel on right-click outside it
        if (button == 1 && settingsTarget != null) {
            settingsTarget = null;
            return true;
        }

        for (CategoryPanel p : panels) {
            Module hit = p.moduleAt((int) mx, (int) my);
            if (hit != null) {
                if (button == 0) {
                    hit.toggle();
                    Br1tanniaClient.getInstance().getConfigManager().save();
                } else if (button == 1) {
                    settingsTarget = hit;
                    settingsX      = (int) mx;
                    settingsY      = (int) my;
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }

    // ── Settings mini-panel ───────────────────────────────────────────────────

    private void renderSettingsPanel(DrawContext ctx, int mx, int my) {
        var settings = settingsTarget.getSettings();
        int panelW = 160;
        int panelH = 20 + settings.size() * 20 + 8;
        int px     = Math.min(settingsX, width  - panelW - 4);
        int py     = Math.min(settingsY, height - panelH - 4);

        RenderUtil.fillRect(ctx, px, py, panelW, panelH, ColorUtil.BG_PANEL);
        RenderUtil.drawOutline(ctx, px, py, panelW, panelH, ColorUtil.ACCENT_BLUE);
        RenderUtil.drawString(ctx, textRenderer,
                settingsTarget.getName(), px + 4, py + 4, ColorUtil.TEXT_PRIMARY);

        int row = py + 18;
        for (var entry : settings.entrySet()) {
            String key = entry.getKey();
            Object val = entry.getValue();
            String line = key + ": " + formatValue(val);
            RenderUtil.drawString(ctx, textRenderer, line,
                    px + 6, row + 2, ColorUtil.TEXT_SECONDARY);

            if (val instanceof Float f) {
                // Simple slider visual
                int trackW = panelW - 12;
                float norm = Math.min(1f, f / 20f); // assume max 20 for display
                RenderUtil.fillRect(ctx, px + 6, row + 12, trackW, 3, ColorUtil.SLIDER_TRACK);
                RenderUtil.fillRect(ctx, px + 6, row + 12, (int)(trackW * norm), 3, ColorUtil.SLIDER_FILL);
                row += 24;
            } else {
                row += 18;
            }
        }
    }

    private String formatValue(Object v) {
        if (v instanceof Float f) return String.format("%.2f", f);
        return String.valueOf(v);
    }

    // ── Inner panel ───────────────────────────────────────────────────────────

    private static class CategoryPanel {
        final Category     category;
        final List<Module> modules;
        final int x, y, w, h;

        CategoryPanel(Category cat, List<Module> mods, int x, int y, int w, int h) {
            this.category = cat;
            this.modules  = mods;
            this.x = x; this.y = y; this.w = w; this.h = h;
        }

        void render(DrawContext ctx,
                    net.minecraft.client.font.TextRenderer font,
                    int mx, int my) {
            // Panel background
            RenderUtil.fillRect(ctx, x, y, w, h, ColorUtil.BG_PANEL);
            RenderUtil.drawOutline(ctx, x, y, w, h, ColorUtil.SEPARATOR);

            // Header
            RenderUtil.fillRect(ctx, x, y, w, PANEL_HEADER, ColorUtil.BG_DARK);
            RenderUtil.drawString(ctx, font,
                    category.displayName, x + 5, y + 5, ColorUtil.ACCENT_BLUE);

            // Module rows
            int ry = y + PANEL_HEADER;
            for (Module m : modules) {
                boolean hover = mx >= x && mx <= x + w && my >= ry && my <= ry + MODULE_HEIGHT;
                int rowBg     = hover ? ColorUtil.BG_DARK : ColorUtil.BG_PANEL;
                int textColor = m.isEnabled() ? ColorUtil.ENABLED_GREEN : ColorUtil.TEXT_PRIMARY;
                int dot       = m.isEnabled() ? ColorUtil.ENABLED_GREEN : ColorUtil.DISABLED_GREY;

                RenderUtil.fillRect(ctx, x, ry, w, MODULE_HEIGHT, rowBg);
                // Coloured indicator bar on the left
                RenderUtil.fillRect(ctx, x, ry, 3, MODULE_HEIGHT, dot);
                RenderUtil.drawString(ctx, font, m.getName(), x + 8, ry + 4, textColor);
                ry += MODULE_HEIGHT;
            }
        }

        /** Returns the module the cursor is over, or null. */
        Module moduleAt(int mx, int my) {
            if (mx < x || mx > x + w) return null;
            int ry = y + PANEL_HEADER;
            for (Module m : modules) {
                if (my >= ry && my <= ry + MODULE_HEIGHT) return m;
                ry += MODULE_HEIGHT;
            }
            return null;
        }
    }
}
