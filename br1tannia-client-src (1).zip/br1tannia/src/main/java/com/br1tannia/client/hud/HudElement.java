package com.br1tannia.client.hud;

import net.minecraft.client.gui.DrawContext;

public abstract class HudElement {
    protected int x, y;
    protected boolean visible = true;

    public abstract void render(DrawContext ctx, float delta);

    public void setPosition(int x, int y) { this.x = x; this.y = y; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean v) { visible = v; }
}
