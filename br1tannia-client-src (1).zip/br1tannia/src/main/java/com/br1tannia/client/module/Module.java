package com.br1tannia.client.module;

import net.minecraft.client.MinecraftClient;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Base class for every Br1tannia module.
 * Extend this, call super(), implement onEnable/onDisable/onTick as needed.
 */
public abstract class Module {

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String   name;
    private final String   description;
    private final Category category;

    private boolean enabled = false;
    private int     keybind = -1; // GLFW key constant, -1 = unbound

    // Generic settings store: name -> value (Boolean, Float, Integer, String)
    private final Map<String, Object> settings = new LinkedHashMap<>();

    protected Module(String name, String description, Category category) {
        this.name        = name;
        this.description = description;
        this.category    = category;
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (enabled) onEnable();
        else         onDisable();
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}

    // ── Settings helpers ─────────────────────────────────────────────────────

    protected void registerBool(String key, boolean def)  { settings.put(key, def); }
    protected void registerFloat(String key, float def)   { settings.put(key, def); }
    protected void registerInt(String key, int def)       { settings.put(key, def); }

    public boolean getBool(String key)  { return (Boolean) settings.getOrDefault(key, false); }
    public float   getFloat(String key) { return (Float)   settings.getOrDefault(key, 0f);    }
    public int     getInt(String key)   { return (Integer) settings.getOrDefault(key, 0);     }

    public void setSetting(String key, Object value) {
        if (settings.containsKey(key)) settings.put(key, value);
    }

    public Map<String, Object> getSettings() { return settings; }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String   getName()        { return name;        }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category;    }
    public boolean  isEnabled()      { return enabled;     }
    public int      getKeybind()     { return keybind;     }
    public void     setKeybind(int k){ keybind = k;        }
}
