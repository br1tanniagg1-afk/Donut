package com.br1tannia.client.mixin;

import com.br1tannia.client.Br1tanniaClient;
import com.br1tannia.client.module.modules.world.BaseSoundDetector;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts every sound the client plays and forwards it to BaseSoundDetector.
 * Uses the public play(SoundInstance) method so it covers both positioned and
 * non-positioned sounds; the detector itself filters by ID.
 */
@Mixin(SoundSystem.class)
public class SoundSystemMixin {

    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V",
            at = @At("HEAD"))
    private void onPlay(SoundInstance sound, CallbackInfo ci) {
        if (Br1tanniaClient.getInstance() == null) return;

        var mm = Br1tanniaClient.getInstance().getModuleManager();
        if (mm == null) return;

        BaseSoundDetector detector =
            (BaseSoundDetector) mm.getByName("BaseSoundDetector");
        if (detector == null || !detector.isEnabled()) return;

        String id = sound.getId().toString();   // "minecraft:block.chest.open"
        double x  = sound.getX();
        double y  = sound.getY();
        double z  = sound.getZ();

        detector.onSoundPlayed(id, x, y, z);
    }
}
